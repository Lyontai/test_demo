//  var newTab = document.getElementById("owoisone");
//  window.open("http://google.com", "height=100, width=200");
//     // newTab.moveTo(500,300);

function newTabs() {
  window.open("http://www.oshodicampaigns.org/blog/");
}
// function socialMediasF(){
//     window.open("https://www.facebook.com/groups/596992770734923");
// }
// function socialMediaT(){
//     window.open("https://www.twitter.com/oda");
// }
// function socialMediaI(){
//     window.open("https://www.instagram.com/oda");
// }
// function socialMediaY(){
//     window.open("https://www.youtube.com/oda");
// }
